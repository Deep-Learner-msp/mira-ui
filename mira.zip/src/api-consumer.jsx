import Mira from "../api-management/main";

const mira = new Mira(window.settings);

export default mira;
