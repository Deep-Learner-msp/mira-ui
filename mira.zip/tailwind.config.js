module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
    // Include other paths where your components and pages are located
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
